package graph;

import java.util.Iterator;
import java.util.List;

public final class DepthFirstSearch{
    private boolean[] visitedVertices;
    private AbstractGraph graph;
    
    public DepthFirstSearch(AbstractGraph graph)
    {
        this.graph = graph;
    }

    public void depthFirstSearch(Vertex source)
    {
        int sourceIndex = this.graph.getVertices().indexOf(source); // Pega o index do vertice atual
        markVertexAsVisited(sourceIndex); // Marca ele como visitado
        
        System.out.println(source.toString()); // Exibe seus dados
        
        Vertex adjacentVertex = this.graph.getFirstConnectedVertex(source); // Pega o primeiro vertice adjacente ao atual
        
        while(adjacentVertex != null){ // Enquanto tiver vertices adjacentes
            if(!visitedVertices[this.graph.getVertices().indexOf(adjacentVertex)]){ // Verifica se ele ja foi visitado
                depthFirstSearch(adjacentVertex); // Caso nao foi visitado, chama a funcao recursivamente para visita-lo
            }
            //Caso ja tenha sido visitado, vai para o proximo vertice adjacente
            adjacentVertex = this.graph.getNextConnectedVertex(source, adjacentVertex); 
        }  
    }
    
    public void depthFirstSearch(int index){
        this.visitedVertices = new boolean[graph.getNumberOfVertices()];
        this.depthFirstSearch(this.graph.getVertices().get(index));
    }

    public void markVertexAsVisited(int vertexIndex){
        visitedVertices[vertexIndex] = true;
    }
}
