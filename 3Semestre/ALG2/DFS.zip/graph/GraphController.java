package graph;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Logger;

public final class GraphController
{
    private static final Logger LOGGER = Logger.getLogger("GraphController.class");

    private GraphController()
    {

    }

    public static void main(String[] args)
    {
        List<Vertex> vertices = new ArrayList<>();

        Scanner input = new Scanner(System.in); // Le a entrada
        
        int numberOfVertex = Integer.parseInt(input.nextLine()); // Le o numero de vertices a partir da entrada
        
        for(int i = 0; i < numberOfVertex; i++){
            vertices.add(new Vertex(input.nextLine(), input.nextLine()));// Le e cria os vertices a partir da entrada
        }
        
        AbstractGraph graph = new DigraphMatrix(vertices);
        
        int numberOfEdge = Integer.parseInt(input.next()); // Le o numero de arestas a partir da entrada
        
        for(int i = 0; i < numberOfEdge; i++){// Le e cria as arestas dos vertices a partir da entrada
            graph.addEdge(graph.getVertices().get(Integer.parseInt(input.next())), graph.getVertices().get(Integer.parseInt(input.next())));
        }
        
        int startVertexSearch = Integer.parseInt(input.next()); // Le o primeiro vertice da busca
        
        input.close();
        
        DepthFirstSearch dfs = new DepthFirstSearch(graph); 
        
        dfs.depthFirstSearch(startVertexSearch); // Faz a busca em profundidade
        
        System.out.println(); // Pular uma linha igual a resposta do runcodes
    }
}
