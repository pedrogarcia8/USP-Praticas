package graph;

public class Vertex
{
    private String questName;
    private String questDescription;
    private int id;
    private static int counter = 0;
    
    public Vertex(String questName, String questDescription)
    {
        this.questName = questName;
        this.questDescription = questDescription;
        this.id = counter;
        this.counter += 1;
    }

    public String getName()
    {
        return questName;
    }

    public void setName(String name)
    {
        this.questName = name;
    }
    
    public int getId(){
        return this.id;
    }

    @Override
    public String toString()
    {
        return "Quest{\n\tID= '"+this.id+"'\n\tname= '"+this.questName+"'\n\tdescription= '"+this.questDescription+"'\n}\n";
    }
}
