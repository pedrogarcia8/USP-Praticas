#include "Includes.h"
// Esta função permite criar uma btree vazia
BTree *createBTree() {
    BTree *bTree;
    bTree = (BTree *) malloc(sizeof(BTree));
    bTree->numberOfNodes = 0;
    bTree->rootNode = 0;
    writeBTreeHeader(bTree);
    addNewNodeToFile(
        createNewNode(bTree)
    );
    return bTree;
}

// Esta função carrega uma btree do arquivo ou cria uma nova
BTree *loadOrCreateBTree() {
    FILE *fp;
    fp = fopen(INDEX_FILE, "r");
    fseek(fp, 0, SEEK_END);
    long int size = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    if (size > 0) {
        return readBTreeFromFile(fp);
    } else {
        return createBTree();
    }
}

// Cria um novo nó e seta seu index com base no número de nós da bTree
Node *createNewNode(BTree *bTree) {
    Node *node;
    node = createNodeObject();
    node->index = bTree->numberOfNodes;
    bTree->numberOfNodes++;
    return node;
}

// escreve o cabeçalho da bTree no arquivo
void writeBTreeHeader(BTree *bTree) {
    FILE *fp;
    fp = fopen(INDEX_FILE, "r+");
    fseek(fp, 0, SEEK_SET);
    writeBtreeHeaderToFile(fp, bTree);
    fclose(fp);
}
