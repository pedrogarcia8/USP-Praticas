#include "Includes.h"

// Esta função inicia o processo de inserção, ela avalia qual procedimento de inserção será necessário
int insertNewEntry(BTree *bTree, Entry *newEntry, Search *search) {
    Node *node;
    int nodeIndex;
    if (search->currentIndex == 0) { // Se currentIndex for zero significa que a recursão chegou ao nó raiz
        nodeIndex = bTree->rootNode;
    } else {
        nodeIndex = search->history[search->currentIndex--]; // Se não for, buscar nó que o elemento será inserido
    }
    node = getNodeByIndex(nodeIndex); // Buscar nó no arquivo
    int insertedEntryIndex;
    if (node->numberOfEntries == NODE_MAX_ENTRIES) { // Se nó o no estiver cheio, fazer overflow
        if (node->index != bTree->rootNode) {
            free(node);
            return hadleLeaveNodeOverflow(bTree, nodeIndex, newEntry, search);
        } else {
            free(node);
            handleRootNodeOverflow(bTree, nodeIndex, newEntry, search);
            return 0;
        }
    } else {
        insertedEntryIndex = addEntryToNode(newEntry, node); // Se não, insira entrada no nó
        free(node);
        return insertedEntryIndex;
    }
}

// Esta função realizará as operações necessárias para lidar com o overflow de um nó folha
int hadleLeaveNodeOverflow(BTree *bTree, int nodeIndex, Entry *newEntry, Search *search) {
    Node *newLeaveNode, *node;

    node = getNodeByIndex(nodeIndex); // Carregar informações do nó

    newLeaveNode = splitNode(bTree, node, newEntry); // Realizar slipt e receber novo nó
    // A chave a ser promovida terá o novo nó como filho, esse filho será invertido com a chave seguinte no nó pai
    newLeaveNode->entries[0].child = newLeaveNode->index;

    updateNode(node);
    updateNode(newLeaveNode);
    int promotedNewIndex = promoteEntry(bTree, newLeaveNode, search);

    updateNode(node);
    updateNode(newLeaveNode);

    free(node);
    free(newLeaveNode);
    return promotedNewIndex;
}

// Esta função realizará as operações pra lidar com o overflow do nó raiz
int handleRootNodeOverflow(BTree *bTree, int nodeIndex, Entry *newEntry, Search *search) {
    Node *newRootNode, *newLeaveNode, *node;
    node = getNodeByIndex(nodeIndex);

    newRootNode = createNewNode(bTree); // Criar um novo nó
    bTree->rootNode = newRootNode->index; // Atualizar nó raiz da btree
    newLeaveNode = splitNode(bTree, node, newEntry);
    newLeaveNode->entries[0].child = node->index; // O nó original terá como nextNode o filho da chave a ser promovida

    newRootNode->nextNode = newLeaveNode->index; // O nextNode do novo nó raiz é o novo nó folha
    updateNode(newRootNode);
    updateNode(newLeaveNode);
    updateNode(node);
    int promotedNewIndex = promoteEntry(bTree, newLeaveNode, search);

    updateNode(node);
    updateNode(newLeaveNode);
    free(newRootNode);
    free(newLeaveNode);
    free(node);

    return promotedNewIndex;
}

// Esta função realizará o split de um nó, resultando em um novo nó folha com metade das entradas do nó original
Node *splitNode(BTree *bTree, Node *node, Entry *newEntry) {
    // Encontrar o meio do nó
    int middle = NODE_MAX_ENTRIES / 2, splitIndex, isNewKeySmaller;
    Node *newNode;
    newNode = createNewNode(bTree); // Criar o novo nó
    newNode->nextNode = node->nextNode; // Como o novo nó receberá as entradas de maior valor, o nextNode do nó antigo deve se tornar o nextNode do nó novo

    // Dependendo da nova entrada escolher a entrada central ou a proxima para iniciar o split
    if (node->entries[middle].key > newEntry->key) {
        isNewKeySmaller = 1;
        splitIndex = middle;
    } else {
        isNewKeySmaller = 0;
        splitIndex = middle + 1;
    }

    // Adicionar entradas no novo nó e removê-las do nó anterior
    for (int i = splitIndex; i < NODE_MAX_ENTRIES; i++) {
        addSortedEntryToNode(&node->entries[i], newNode);
        removeEntry(&node->entries[i]);
        node->numberOfEntries--;
    }
    node->nextNode = newNode->entries[0].child; // nextNode do nó original será o o filho da chave a ser promovida

    // Dependendo do tamanho da nova entrada, adiciona-la em um dos nós
    if (isNewKeySmaller) {
        addEntryToNode(newEntry, node);
    } else {
        addEntryToNode(newEntry, newNode);
    }
    return newNode;
}

// Esta funnção realiza a promoção de uma chave, chamando a função insertNewEntry
// recursivamente para inseri-las no nó anterior, que está registrado no historico de busca
int promoteEntry(BTree *bTree, Node *childNode, Search *search) {
    int index = insertNewEntry(
        bTree,
        &childNode->entries[0],
        search
    );
    removeEntryAndRearrangeNode(&childNode->entries[0], childNode); // remover a entrada promovida e reorganizar o nó
    return index;
}


