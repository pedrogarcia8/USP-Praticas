# Grupo 06

# Integrantes
    - Thiago Ribeiro Govêia n°USP 10835942
    - Pedro José Garcia n°USP 11846943
    - Altair Fernando Pereira Junior n°USP 9391831