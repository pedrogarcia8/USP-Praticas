#include "Includes.h"

// Esta função realizará a busca de um nUSP na bTree, mantendo um histórico dos nós visitados
void getRRNByPrimaryKey(Result * result, int nodeIndex, int nUSP, Search *search){
    int position = -1, nextIndex;

    Node *node = getNodeByIndex(nodeIndex);
    position = keyPositionSearch(node->entries, 0, node->numberOfEntries, nUSP); // Compara entradas do nó com o nUSP e retorna -1 se ele não for encontrado
    // Se posição naõ foi encontrada buscar no filho do primeiro nó se existir ou returnar resultado da busca mal sucedido
    if (position < 0) {
        if (node->nextNode < 0) {
            result->entry.key = -1;
            result->node = node;
            return;
        } else {
            nextIndex = node->nextNode;
            search->history = (int *) realloc(search->history, sizeof(int) * ++search->currentIndex + 1);
            search->history[search->currentIndex] = nextIndex;
            free(node);
            getRRNByPrimaryKey(result, nextIndex, nUSP, search);
        }
    // Se posição maior que zero então existe uma entrada maior ou igual ao nUSP
    } else {
        //  Se for igual retorne o nó e a entrada encontrada
        if(node->entries[position].key == nUSP){
            result->entry = node->entries[position];
            result->node = node;
            return;
        // Se for maior e não possuir um filho, retorne busca mal sucedida
        }else if(node->entries[position].key > nUSP){
            if (node->entries[position].child == -1) {
                result->entry.key = -1;
                result->node = node;
                return;
            }
            // Caso contrario atidicion nó ao histórico e busque no proximo nó
            nextIndex = node->entries[position].child;
            search->history = (int *) realloc(search->history, sizeof(int) * ++search->currentIndex + 1);
            search->history[search->currentIndex] = nextIndex;
            free(node);
            getRRNByPrimaryKey(result, nextIndex, nUSP, search);
        }
    }

}

// Compara as chavas das entradas até econtrar um valor maior ou igual ao valro provido
int keyPositionSearch(Entry * entries, int start, int end, int value) {
    for (int i = 0; i < end; i++) {
        if (entries[i].key >= value) {
            return i;
        }
    }
    return -1;
}