#ifndef SEARCH_H_
#define SEARCH_H_

#include "Includes.h"

void getRRNByPrimaryKey(Result * result, int nodeIndex, int nUSP, Search *search);
int keyPositionSearch(Entry * entries, int start, int end, int value);

#endif