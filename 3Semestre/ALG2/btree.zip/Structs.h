#ifndef STRUCTS_H_
#define STRUCTS_H_

#include "Includes.h"

// Este arquivo centraliza as structs para facilitar a organização

typedef struct Entry {
    int key; // nUSP
    long int rrn; //rrn do registro do estudante
    int child; // index do nó filho (nó com chaves menores)
} Entry;

typedef struct Node {
    int index; // usado para identificar um nó
    int numberOfEntries; // número de entradas preenchidas
    Entry entries[NODE_MAX_ENTRIES]; // vetor de entradas
    int nextNode; // index do proximo nó, ou seja, aquele con chaves maiores do que o nó atual
} Node;

typedef struct Student
{
    int nUSP;
    char name[STRING_FIELD_SIZE];
    char surname[STRING_FIELD_SIZE];
    char course[STRING_FIELD_SIZE];
    float grade;
} Student;

typedef struct BTree {
    int numberOfNodes; // número total de nós
    int rootNode; // nó raiz da arvore
} BTree;

typedef struct result {
    Entry entry; // O resultado reune uma entrada
    Node * node; // e o nó onde ela foi encontrada
} Result;

typedef struct Search {
    int currentIndex; // este valor representa o index do vetor history qye está em uso atualmente
    int *history; // vetor que reuno os indexes de todos os nós visitados na busca
} Search;

#endif
