package graph;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Logger;
import java.lang.Math;
import java.util.Locale;

public final class GraphController
{
    private static final Logger LOGGER = Logger.getLogger("GraphController.class");

    private GraphController()
    {
        
    }

    public static void main(String[] args)
    {
        List<Vertex> vertices = new ArrayList<>();
        
        Scanner input = new Scanner(System.in); // Le a entrada

        int numberOfVertex = Integer.parseInt(input.nextLine()); // Le o numero de vertices a partir da entrada
        String entrada;
        int entradaX;
        int entradaY;
        
        for(int i = 0; i < numberOfVertex; i++){
            entrada = input.next(); // Le uma linha inteira da entrada 
            entradaX = Integer.parseInt(entrada.split(",")[0]); // Pega o valor do "x" na entrada
            entradaY = Integer.parseInt(entrada.split(",")[1]); // Pega o valor do "y" na entrada
            vertices.add(new Vertex(entradaX, entradaY));// Cria o vertice
            
        }
        
        var graphController = new GraphController();

        AbstractGraph graph = new DigraphMatrix(vertices);
        
        int numberOfEdge = Integer.parseInt(input.next()); // Le o numero de arestas a partir da entrada
        
        int indexOfVertex1 = 0;
        int indexOfVertex2 = 0;
        float edgeWeight = 0;
        
        for(int i = 0; i < numberOfEdge; i++){
            entrada = input.next();// Le uma linha inteira da entrada

            entradaX = Integer.parseInt(entrada.split(":")[0].split(",")[0]); // Pega o valor do "x" do primeiro vertice na entrada
            entradaY = Integer.parseInt(entrada.split(":")[0].split(",")[1]); // Pega o valor do "y" do primeiro vertice na entrada
            
            indexOfVertex1 = getIndexOfVertex(vertices, entradaX, entradaY); // Pega o indice do primeiro vertice
            entradaX = Integer.parseInt(entrada.split(":")[1].split(",")[0]); // Pega o valor do "x" do segundo vertice na entrada
            entradaY = Integer.parseInt(entrada.split(":")[1].split(",")[1]); // Pega o valor do "y" do segundo vertice na entrada
            
            indexOfVertex2 = getIndexOfVertex(vertices, entradaX, entradaY); // Pega o indice do segundo vertice
            edgeWeight = getEuclideanDistance(vertices, indexOfVertex1, indexOfVertex2); // Calcula a distancia euclidiana entre os vertices
            
            graph.addEdge(graph.getVertices().get(indexOfVertex1), graph.getVertices().get(indexOfVertex2), edgeWeight); // Cria a aresta
        }
        
        TraversalStrategyInterface traversalStrategy = new FloydWarshallTraversal(graph);
        traversalStrategy.traverseGraph(graph.getVertices().get(0));
        if(traversalStrategy instanceof FloydWarshallTraversal)
        {
           Vertex centerVertex = graph.getCentermostVertex(((FloydWarshallTraversal) traversalStrategy).getDistanceMatrix()); // Busca o vertice central
           float[][] distanceMatrix = ((FloydWarshallTraversal) traversalStrategy).getDistanceMatrix(); // Pega a matriz de distancias
           Vertex morePeripheralVertex = graph.getMorePeripheralVertex(distanceMatrix); // Pega o vertice mais periferico

           System.out.println(centerVertex.toString()); // Exibe o vertice central
           System.out.println(morePeripheralVertex.toString()); // Exibe o vertice mais periferico
           
           //Pega o indice do vertice mais periferico
           int indexOfMorePeripheralVertex = getIndexOfVertex(vertices, morePeripheralVertex.getX(), morePeripheralVertex.getY());
           
           //Pega o indice do vertice mais distante do vertice mais periferico
           int indexOfFartherVertexOfMorePeripheralVertex = graph.getMaxDistanceIndexInCollumn(distanceMatrix, indexOfMorePeripheralVertex);
           
           //Exibe o vertice mais distante do vertice mais periferico
           System.out.println(vertices.get(indexOfFartherVertexOfMorePeripheralVertex).toString());
        }
        
    }
    
    public static int getIndexOfVertex(List<Vertex> vertices, int x, int y){ // Pega o indice de um vertice, baseado nas coordenadas
        for(int i = 0; i < vertices.size(); i++){
            if(vertices.get(i).getX() == x && vertices.get(i).getY() == y)
                return i;
        }
        
        return -1;
    }
    
    // Calcula a distancia euclidiana entre dois vertices
    public static float getEuclideanDistance(List<Vertex> vertices, int indexOfVertex1, int indexOfVertex2){
        int x1 = vertices.get(indexOfVertex1).getX();
        int x2 = vertices.get(indexOfVertex2).getX();
        
        int y1 = vertices.get(indexOfVertex1).getY();
        int y2 = vertices.get(indexOfVertex2).getY();
        
        float distance = (float) Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
        
        return distance;
    }
}
