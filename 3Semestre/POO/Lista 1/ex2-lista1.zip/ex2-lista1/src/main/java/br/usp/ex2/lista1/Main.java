/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.usp.ex2.lista1;

/**
 *
 * @author Thiago
 */
public class Main {
    public static void main(String args[]){
        SO pc = new SO();
        
        pc.executaTeste();
        
        pc.dRede.enviaPacoteDeDados(5, 32);
        pc.dVideo.alteraBrilhoDeExibição(0.75f);
        pc.dImpressora.imprimePaginas(10);
        
        pc.executaTeste();
        
        pc.ligaDispositivo();
        
        pc.dRede.enviaPacoteDeDados(5, 32);
        pc.dVideo.alteraBrilhoDeExibição(0.75f);
        pc.dImpressora.imprimePaginas(10);
        
        pc.executaTeste();
        
        pc.dImpressora.desligaDispositivo();
        
        pc.dImpressora.imprimePaginas(25);
        
        pc.executaTeste();
    }
}
