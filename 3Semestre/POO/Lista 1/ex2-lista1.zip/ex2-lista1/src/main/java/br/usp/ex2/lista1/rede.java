/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.usp.ex2.lista1;

/**
 *
 * @author Thiago
 */
public class rede {
    boolean power;
    
    rede(){
        power = false;
    }
    
    public void ligaDispositivo(){
        if(power){
            System.out.println("Driver de rede já está ligada!");
        }
        else{
            power = true;
            System.out.println("Ligando driver de rede...");
        }
    }

    public void desligaDispositivo(){
        if(!power){
            System.out.println("Driver de rede já está desligado!");
        }
        else{
            power = false;
            System.out.println("Desligando driver de rede...");
        }
    }

    public void verificaStatus(){
        if(power){
            System.out.println("Driver de rede ligado");
        }
        else{
            System.out.println("Driver de rede desligado");
        }
    }

    public void executaTeste(){
        if(power){
            System.out.println("Enviando 4 pacotes de tamanho 32...");
            System.out.println("Teste concluído!");
        }
        else{
            System.out.println("Impossível realizar teste! Driver de rede offline!");
        }
    }
    
    public void enviaPacoteDeDados(int tamDados, int nPacotes){
        if(power){
            System.out.println("Enviando " + nPacotes + " pacotes de dados de tamanho " + tamDados);
        }
        else{
            System.out.println("Não foi possível enviar o pacote de dados pois o driver de rede está desligado!");
        }
    }
}
