package br.usp.ex3.lista1;

public class Polinomio {
    int grau;
    float vetorTermos[];
    
    Polinomio(int grau){
        this.grau = grau + 1; // Define o grau do polinômio
        this.vetorTermos = new float[this.grau]; // Aloca o vetor de termos no tamanho do grau
    }
    
    public void add(float termo, int grauTermo){
        if(grauTermo >= this.grau){// Se o grau do termo for maior que o grau do polinômio, retorna erro
            System.out.println("Erro: O grau do termo inserido é maior que o grau do polinomio!");
            return;
        }else{
            Termo t = new Termo(); // Cria um objeto para o termo
            t.setTermo(termo);// Define este objeto

            if(this.vetorTermos[grauTermo] == 0)
                this.vetorTermos[grauTermo] = t.getTermo(); //Se ainda não existir um termo com esse grau
            else
                this.vetorTermos[grauTermo] += t.getTermo(); //Se já existir um termo com esse grau, soma eles
        }
    }
    
    public void mostra(){
        System.out.print("P(x) = ");
        for(int i = this.vetorTermos.length-1; i >= 0; i--){
            if(i == 0)
                System.out.print(this.vetorTermos[i]+" "); // Se for elevado a 0, mostra sem o X e sem o expoente
            else{
                if(this.vetorTermos[i] < 0)
                    System.out.print(this.vetorTermos[i]+"x^"+i+" ");
                else if(this.vetorTermos[i] > 0)
                    System.out.print("+"+this.vetorTermos[i]+"x^"+i+" ");// Se for positivo, adiciona o sinal de "mais"
            }  
        }
        System.out.println(); //Pular linha no final
    }
    
    public float calcula(float valor){
        float valorCalculado = 0;
        
        for(int i = this.vetorTermos.length-1; i >= 0; i--){
            valorCalculado += Math.pow(valor,i) * vetorTermos[i];
        }
        
        return valorCalculado;
    }
    
}
