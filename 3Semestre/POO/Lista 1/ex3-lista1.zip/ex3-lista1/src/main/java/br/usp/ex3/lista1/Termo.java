package br.usp.ex3.lista1;

public class Termo {
   float termo;
   
   Termo(){
       this.termo = 0; // inicializa
   }
   
   public void setTermo(float termo){
       this.termo = termo; // define o termo
   }
   
   public float getTermo(){
       return this.termo; // retorna o termo
   }
}
