package br.usp.lista02.ex05;

public class SuperHeroi extends Personagem{
    SuperHeroi(String pNome, String pNomeVidaReal, Superpoder pSuperpoder, int pVida){
        super(pNome, pNomeVidaReal, pSuperpoder, pVida);
    }
}
