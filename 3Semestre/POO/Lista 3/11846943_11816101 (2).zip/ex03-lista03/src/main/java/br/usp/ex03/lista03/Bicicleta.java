package br.usp.ex03.lista03;

public class Bicicleta implements PegadaDeCarbono{
    private int _aro, _numMarchas;
    private float _pegada;
    
    Bicicleta(int iAro, int iNumMarchas, float fPegada){
        _aro = iAro;
        _numMarchas = iNumMarchas;
        _pegada = fPegada;
    }
    
    public float getPegadaDeCarbono() {
        return _pegada;
    }
    
}
