package br.usp.ex03.lista03;

public class Carro implements PegadaDeCarbono{
    private int _km, _velMax;
    private float _pegada;
    
    Carro(int iKm, int iVelMax, float fPegada){
        _km = iKm;
        _velMax = iVelMax;
        _pegada = fPegada;
    }
    
    public float getPegadaDeCarbono() {
        return _pegada;
    }
    
}
