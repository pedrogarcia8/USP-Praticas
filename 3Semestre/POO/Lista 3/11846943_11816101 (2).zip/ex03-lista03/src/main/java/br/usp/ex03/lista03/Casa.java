package br.usp.ex03.lista03;

public class Casa extends Predio{
    private int _numQuartos;
    
    Casa(String sCor, int iAndares, float fPegada, int iNumQuartos){
        super(sCor, iAndares, fPegada);
        _numQuartos = iNumQuartos;
    }
}
