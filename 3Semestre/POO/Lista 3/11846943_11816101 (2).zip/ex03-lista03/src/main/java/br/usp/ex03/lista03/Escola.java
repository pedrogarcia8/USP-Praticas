package br.usp.ex03.lista03;

public class Escola extends Predio{
    private int _numSalas;
    
    Escola(String sCor, int iAndares, float fPegada, int iNumSalas){
        super(sCor, iAndares, fPegada);
        _numSalas = iNumSalas;
    }
}
