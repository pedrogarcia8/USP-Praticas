package br.usp.ex03.lista03;

import java.util.ArrayList;

public class Main {
    public static void main(String args[]){
        ArrayList<PegadaDeCarbono> objetos = new ArrayList();
        
        Casa Lutfalla = new Casa("Amarelo", 48, 1300.54f, 3);
        Casa Episcopal = new Casa("Cinza", 145, 1156.7f, 2);
        Escola Estadual = new Escola("Branco", 121, 1648.67f, 20);
        Escola Municipal = new Escola("Azul", 245, 987.4f, 8);
        Carro Gol = new Carro(70000, 210, 456.7f);
        Carro BMW = new Carro(0, 320, 680.64f);
        Bicicleta Caloi = new Bicicleta(17, 5, 120.21f);
        Bicicleta Cannondale = new Bicicleta(29, 21, 150.7f);
        
        objetos.add(Lutfalla);
        objetos.add(Episcopal);
        objetos.add(Estadual);
        objetos.add(Municipal);
        objetos.add(Gol);
        objetos.add(BMW);
        objetos.add(Caloi);
        objetos.add(Cannondale);
        
        for(int i = 0; i < objetos.size(); i++){
            System.out.println("Objeto " + i + ": " + objetos.get(i).getPegadaDeCarbono());
        }
    }
}
