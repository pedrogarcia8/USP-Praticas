package br.usp.ex03.lista03;

public interface PegadaDeCarbono {
    public float getPegadaDeCarbono();
}
