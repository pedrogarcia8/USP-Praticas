package br.usp.ex03.lista03;

public abstract class Predio implements PegadaDeCarbono{
    private String _cor;
    private int _numero;
    private float _pegada;
    
    Predio(String sCor, int iNumero, float fPegada){
        _cor = sCor;
        _numero = iNumero;
        _pegada = fPegada;
    }
    
    public float getPegadaDeCarbono() {
        return _pegada;
    }
    
}
