package br.usp.ex04.lista03;

public class Produto {
    protected int codigo;
    protected float precoUnitario;
    protected String descricao;
    protected int quantidadeEstoque;
    
    Produto(int codigo, float precoUnitario, String descricao, int quantidadeEstoque){
        this.codigo = codigo;
        this.precoUnitario = precoUnitario;
        this.descricao = descricao;
        this.quantidadeEstoque = quantidadeEstoque;
    }
    
    void setPrecoUnitario(float precoUnitario){
        this.precoUnitario = precoUnitario;
    }
    
    float getPrecoUnitario(){
        return this.precoUnitario;
    }
    
    void setDescricao(String descricao){
        this.descricao = descricao;
    }
    
    String getDescricao(){
        return this.descricao;
    }
    
    int getCodigo(){
        return this.codigo;
    }
    
    int getQuantidadeEstoque(){
        return this.quantidadeEstoque;
    }
    
    int retirarQuantidadeEstoque(int quantidade){
        int quantidadeRetirada = 0;
        if((this.quantidadeEstoque - quantidade) < 0){
            quantidadeRetirada = this.quantidadeEstoque;
            this.quantidadeEstoque = 0;
        }else{
            this.quantidadeEstoque -= quantidade;
            quantidadeRetirada = quantidade;
        }
        
        return quantidadeRetirada;
    }
    
    void acrescentarQuantidadeEstoque(int quantidade){
        this.quantidadeEstoque += quantidade;
    }
    
    void imprimirProduto(){
        System.out.println("Produto "+this.codigo+", "+this.descricao+", custo de R$"+this.precoUnitario+", quantidade "+this.quantidadeEstoque);
    }
}
