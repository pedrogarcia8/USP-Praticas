package br.usp.ex04.lista03;

import java.util.Date;

public class ProdutoPerecivelEspecial extends ProdutoPerecivel{
    
    public ProdutoPerecivelEspecial(int codigo, float precoUnitario, String descricao, int quantidadeEstoque, Date dataValidade) {
        super(codigo, precoUnitario, descricao, quantidadeEstoque, dataValidade);
    }
    
    void imprimirNotaControle(){
        System.out.println("==Nota de controle==");
        System.out.println("Código: "+ this.codigo);
        System.out.println("Descrição: "+ this.descricao);
        System.out.println("Quantidade em estoque: "+ this.quantidadeEstoque);
        System.out.println("Data de validade: "+ this.dataValidade);
    }
    
}
