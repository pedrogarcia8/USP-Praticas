/*
Essa seria a solução para que os desenvolvedores
de dispositivos pudessem desenvolver dispositivos
para este sistema
*/

package br.usp.ex06.lista03;

public interface Drivers {
    public void onOff();
    public int checkStatus();
    public void calibrate();
}
