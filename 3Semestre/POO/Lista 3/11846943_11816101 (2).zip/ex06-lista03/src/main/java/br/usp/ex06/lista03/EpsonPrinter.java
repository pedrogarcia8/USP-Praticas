package br.usp.ex06.lista03;

public class EpsonPrinter extends Printer{
    EpsonPrinter(){
        super();
        System.out.println("Obrigado por escolher a Epson!");
    }
    
    public void calibrate(){
        super.calibrate();
        System.out.println("Impressora ultra potente da Epson está calibrada!");
    }
}
