package br.usp.ex06.lista03;

public class HpPrinter extends Printer{
    HpPrinter(){
        super();
        System.out.println("A HP agradace a sua escolha!");
        System.out.println("HP, a marca preferida das famílias brasileiras!");
    }
    
    public void calibrate(){
        super.calibrate();
        System.out.println("Impressora HP calibradíssima!");
    }
}
