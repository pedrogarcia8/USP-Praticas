package br.usp.ex06.lista03;

public class Keyboard implements Drivers {
    private boolean _power = false;
    
    Keyboard(){
        System.out.println("Teclado configurado!");
    }
    
    public void onOff() {
        _power = !(_power);
        if(_power){
            System.out.println("O teclado agora está online");
        }
        else{
            System.out.println("O teclado agora está offline");
        }
    }

    public int checkStatus() {
        if(_power){
            System.out.println("O teclado está online");
            return 1;
        }
        else{
            System.out.println("O teclado agora está offline");
            return 0;
        }
    }

    public void calibrate() {
        System.out.println("Calibrando...");
        System.out.println(".");
        System.out.println(".");
        System.out.println(".");
        System.out.println(".");
        System.out.println(".");
        System.out.println("Calibrado");
    }
}
