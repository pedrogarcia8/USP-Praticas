package br.usp.ex06.lista03;

import java.util.ArrayList;

public class Main {
    public static void main(String args[]){
        ArrayList<Drivers> dispositivos = new ArrayList();
        
        Video video = new Video();
        System.out.println("");
        Printer impressoraEpson = new EpsonPrinter();
        System.out.println("");
        Printer impressoraSamsung = new SamsungPrinter();
        System.out.println("");
        Printer impressoraHp = new HpPrinter();
        System.out.println("");
        Mouse mouse = new Mouse();
        System.out.println("");
        Keyboard teclado = new Keyboard();
        System.out.println("");
        
        dispositivos.add(video);
        dispositivos.add(impressoraEpson);
        dispositivos.add(impressoraSamsung);
        dispositivos.add(impressoraHp);
        dispositivos.add(mouse);
        dispositivos.add(teclado);
        
        System.out.println("");
        for(int i = 0; i < dispositivos.size(); i++){
            dispositivos.get(i).onOff();
        }
        
        System.out.println("");
        for(int i = 0; i < dispositivos.size(); i++){
            dispositivos.get(i).checkStatus();
        }
        
        System.out.println("");
        for(int i = 0; i < dispositivos.size(); i++){
            dispositivos.get(i).calibrate();
        }
    }
}
