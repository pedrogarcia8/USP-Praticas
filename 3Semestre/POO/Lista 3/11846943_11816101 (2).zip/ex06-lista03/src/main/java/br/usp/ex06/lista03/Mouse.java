package br.usp.ex06.lista03;

public class Mouse implements Drivers {
    private boolean _power = false;
    
    Mouse(){
        System.out.println("Mouse configurado!");
    }
    
    public void onOff() {
        _power = !(_power);
        if(_power){
            System.out.println("O mouse agora está online");
        }
        else{
            System.out.println("O mouse agora está offline");
        }
    }

    public int checkStatus() {
        if(_power){
            System.out.println("O mouse está online");
            return 1;
        }
        else{
            System.out.println("O mouse agora está offline");
            return 0;
        }
    }

    public void calibrate() {
        System.out.println("Calibrando...");
        System.out.println(".");
        System.out.println(".");
        System.out.println(".");
        System.out.println(".");
        System.out.println(".");
        System.out.println("Calibrado");
    }
}
