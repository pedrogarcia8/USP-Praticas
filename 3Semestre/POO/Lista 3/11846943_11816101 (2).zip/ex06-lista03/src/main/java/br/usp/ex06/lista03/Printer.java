/*
Essa seria a solução para a criação de toda uma família de
drivers que tem funcionalidades comuns
e que possuem especificidades em cada uma de sua variações
*/

package br.usp.ex06.lista03;

public abstract class Printer implements Drivers {
    private boolean _power = false;
    
    Printer(){
        System.out.println("Impressora configurada!");
    }
    
    public void onOff() {
        _power = !(_power);
        if(_power){
            System.out.println("A impressora agora está online");
        }
        else{
            System.out.println("A impressora agora está offline");
        }
    }

    public int checkStatus() {
        if(_power){
            System.out.println("A impressora está online");
            return 1;
        }
        else{
            System.out.println("A impressora agora está offline");
            return 0;
        }
    }

    public void calibrate() {
        System.out.println("Calibrando...");
        System.out.println(".");
        System.out.println(".");
        System.out.println(".");
        System.out.println(".");
        System.out.println(".");
        System.out.println("Calibrado");
    }
}
