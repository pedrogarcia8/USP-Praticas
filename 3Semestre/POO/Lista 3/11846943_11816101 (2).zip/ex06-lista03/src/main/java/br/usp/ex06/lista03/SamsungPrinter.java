package br.usp.ex06.lista03;

public class SamsungPrinter extends Printer{
    SamsungPrinter(){
        super();
        System.out.println("As impressoras Samsung são as melhores do mercado!");
        System.out.println("Obrigado por preferir a Samsung, marca #1 no mundo!");
    }
    
    public void calibrate(){
        super.calibrate();
        System.out.println("Impressora Samsung tá calibradinha! No capricho!");
    }
}
