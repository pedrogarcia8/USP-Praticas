package br.usp.ex08.lista03;

public class TimeFutebol implements Comparable{
    String nome;
    int vitorias;
    int derrotas;
    int empates;
    int golsMarcados;
    int golsSofridos;
    int amarelos;
    int vermelhos;
    
    TimeFutebol(String nome, int vitorias, int derrotas, int empates, int golsMarcados, int golsSofridos, int amarelos, int vermelhos){
       this.nome = nome;
       this.vitorias = vitorias;
       this.derrotas = derrotas;
       this.empates = empates;
       this.golsMarcados = golsMarcados;
       this.golsSofridos = golsSofridos;
       this.amarelos = amarelos;
       this.vermelhos = vermelhos;
    }
    
    int getPontuacao(){
        return this.vitorias * 3 + this.empates;
    }

    public int compareTo(Object objeto) {
        TimeFutebol time = (TimeFutebol) objeto;
        
        if(this.getPontuacao() > time.getPontuacao())
            return +1;
        else if(this.getPontuacao() < this.getPontuacao())
            return -1;
        else{
            if(this.vitorias > time.vitorias)
                return +1;
            else if(this.vitorias < time.vitorias)
                return -1;
            else{
                int saldoGolsTime1 = this.golsMarcados - this.golsSofridos;
                int saldoGolsTime2 = time.golsMarcados - time.golsSofridos;

                if(saldoGolsTime1 > saldoGolsTime2)
                    return +1;
                else if(saldoGolsTime1 < saldoGolsTime2)
                    return -1;
                else{
                    if(this.golsMarcados > time.golsMarcados)
                        return +1;
                    else if(this.golsMarcados < time.golsMarcados)
                        return -1;
                    else{
                        if(this.vermelhos > time.vermelhos)
                            return -1;
                        else if(this.vermelhos < time.vermelhos)
                            return +1;
                        else{
                            if(this.amarelos > time.amarelos)
                                return -1;
                            else if(this.amarelos < time.amarelos)
                                return +1;
                            else{
                                int numeroSorteado = (int) Math.random() * 2 + 1;
                                
                                //se sortear o número 1 o time 1 fica na posição superior
                                if(numeroSorteado == 1)
                                    return +1;
                                else
                                    return -1;
                            }
                        }
                    }
                }
            }
        }
    }
    
    
}
