package br.usp.ex04.lista03;

import java.util.ArrayList;
import java.util.Date;

public class Estoque {
    protected ArrayList<Produto> estoque;
    
    Estoque(){
        estoque = new ArrayList();
    }
    
    void cadastrarProdutoPerecivel(int codigo, float precoUnitario, String descricao, int quantidadeEstoque, Date dataValidade){
        estoque.add(new ProdutoPerecivel(codigo, precoUnitario, descricao, quantidadeEstoque, dataValidade));
    }
    
    void cadastrarProdutoPerecivelEspecial(int codigo, float precoUnitario, String descricao, int quantidadeEstoque, Date dataValidade){
        estoque.add(new ProdutoPerecivel(codigo, precoUnitario, descricao, quantidadeEstoque, dataValidade));
    }
    
    void cadastrarProdutoNaoPerecivel(int codigo, float precoUnitario, String descricao, int quantidadeEstoque, int tempoGarantiaAnos){
        estoque.add(new ProdutoNaoPerecivel(codigo, precoUnitario, descricao, quantidadeEstoque, tempoGarantiaAnos));
    }
    
    Produto consultarProduto(int codigo){

        for(Produto produto : estoque){
            if(produto.getCodigo() == codigo)
                return produto;
        }
        
        return null;
    }
    
    void retirarProdutoEstoque(int codigo){
        Produto produtoRetirado = this.consultarProduto(codigo);
        
        if(produtoRetirado != null)
            estoque.remove(produtoRetirado);
    }
    
    void custoTotalEstoque(){
        float custoTotal = 0;
        for(Produto produto : estoque){
            custoTotal += (produto.getQuantidadeEstoque() * produto.getPrecoUnitario());
        }
        
        System.out.println("Custo total do estoque R$" + custoTotal);
    }
    
    void imprimirDescricaoProdutosEstoque(){
        for(Produto produto : estoque){
            produto.imprimirProduto();
        }
    }
}
