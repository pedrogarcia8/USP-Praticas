package br.usp.ex04.lista03;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Main {
    public static void main(String args[]) throws ParseException{
        Estoque estoque = new Estoque();
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        
        estoque.cadastrarProdutoPerecivel(1, 8, "arroz" , 80, (Date) formato.parse("01/06/2021"));
        estoque.cadastrarProdutoPerecivelEspecial(2, (float) 4.5, "coca" , 100, (Date) formato.parse("11/06/2022"));
        estoque.cadastrarProdutoNaoPerecivel(3, 9, "Barra de chocolate" , 123, 1);
        estoque.cadastrarProdutoNaoPerecivel(4, 5, "Bolacha" , 10, 2);
        
        Produto produtoEncontrado = estoque.consultarProduto(3);
        System.out.print("Produto Encontrado: ");
        produtoEncontrado.imprimirProduto();
        
        produtoEncontrado.acrescentarQuantidadeEstoque(27);
        System.out.println();
        produtoEncontrado.imprimirProduto();
        
        System.out.println();
        int quantidadeRetirada = produtoEncontrado.retirarQuantidadeEstoque(200);
        System.out.println("Quantidade retirada: "+ quantidadeRetirada);
        
        System.out.println();
        estoque.custoTotalEstoque();
        
        System.out.println();
        estoque.imprimirDescricaoProdutosEstoque();
        
        //----------Testando a parte de retirar e acrescentar quantidade para produto perecível------------------
        System.out.println();
        ProdutoPerecivelEspecial produtoPerecivelEspecial = new ProdutoPerecivelEspecial(5, (float) 4.5, "coca" , 100, (Date) formato.parse("01/06/2022"));
       
        produtoPerecivelEspecial.imprimirNotaControle();
        System.out.println();
        
        if(produtoPerecivelEspecial.adicionarQuantidadeEstoque(10))
            System.out.println("Foi possível adicionar mais quantidade a esse produto");
        else
            System.out.println("Não foi possível adicionar mais quantidade a esse produto");
        
        quantidadeRetirada = produtoPerecivelEspecial.retirarQuantidadeEstoque(20, new Date());
        System.out.println();
        
        System.out.println("Quantidade Retirada: " + quantidadeRetirada);
        System.out.println();
        
        produtoPerecivelEspecial.imprimirProduto();
        //-------------------------------------------------------------------------------------------------------
    }
}
