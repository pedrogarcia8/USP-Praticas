package br.usp.ex04.lista03;

public class ProdutoNaoPerecivel extends Produto{
    protected int tempoGarantiaAnos;
    
    public ProdutoNaoPerecivel(int codigo, float precoUnitario, String descricao, int quantidadeEstoque, int tempoGarantiaAnos) {
        super(codigo, precoUnitario, descricao, quantidadeEstoque);
        
        this.tempoGarantiaAnos = tempoGarantiaAnos;
    }
    
    int getTempoGarantia(){
        return this.tempoGarantiaAnos;
    }
}
