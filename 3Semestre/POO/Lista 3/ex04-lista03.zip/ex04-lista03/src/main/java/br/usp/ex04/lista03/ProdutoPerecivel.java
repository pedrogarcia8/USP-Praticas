package br.usp.ex04.lista03;

import java.util.Date;


public class ProdutoPerecivel extends Produto{
    protected Date dataValidade;
            
    public ProdutoPerecivel(int codigo, float precoUnitario, String descricao, int quantidadeEstoque, Date dataValidade) {
        super(codigo, precoUnitario, descricao, quantidadeEstoque);
        
        this.dataValidade = dataValidade;
    }
    
    void setDataValidade(Date dataValidade){
        this.dataValidade = dataValidade;
    }
    
    Date getDataValidade(){
        return this.dataValidade;
    }
    
    int retirarQuantidadeEstoque(int quantidade, Date dataAtual){
        int quantidadeRetirada = 0;
        long intervaloEntreDatas; // Em dias
        
        intervaloEntreDatas = (dataAtual.getTime() - this.dataValidade.getTime()) / (1000 * 60 * 60 * 24);
        
        if(Math.abs(intervaloEntreDatas) <= 30){
            this.quantidadeEstoque = 0;
            return 0;
        }else{
            if((this.quantidadeEstoque - quantidade) < 0){
                quantidadeRetirada = this.quantidadeEstoque;
                this.quantidadeEstoque = 0;
            }else{
                this.quantidadeEstoque -= quantidade;
                quantidadeRetirada = quantidade;
            }

            return quantidadeRetirada;
        }
    }
    
    boolean adicionarQuantidadeEstoque(int quantidade){
        if(this.quantidadeEstoque == 0){
            this.quantidadeEstoque += quantidade;
            return true;
        }else
            return false;
    }
    
}
