package br.usp.ex08.lista03;

import java.util.ArrayList;
import java.util.Collections;

public class Main {
    public static void main(String args[]){
        ArrayList<TimeFutebol> times = new ArrayList();
        
        times.add(new TimeFutebol("Santos", 12, 0, 0, 20, 3, 2, 0));
        times.add(new TimeFutebol("Palmeiras", 7, 3, 2, 10, 6, 3, 1));
        times.add(new TimeFutebol("São Paulo", 7, 3, 2, 10, 6, 3, 1));
        times.add(new TimeFutebol("Corinthians", 1, 8, 3, 5, 17, 5, 2));
        times.add(new TimeFutebol("Bragantino", 8, 4, 0, 15, 6, 4, 0));
        times.add(new TimeFutebol("Ponte Preta", 5, 2, 5, 9, 14, 1, 1));
        times.add(new TimeFutebol("Guarani", 5, 2, 5, 10, 14, 2, 0));
        times.add(new TimeFutebol("Novorizontino", 3, 7, 2, 10, 11, 2, 1));
        times.add(new TimeFutebol("Ituano", 4, 6, 2, 12, 13, 1, 0));
        times.add(new TimeFutebol("Mirassol", 4, 6, 2, 13, 14, 2, 0));
        times.add(new TimeFutebol("São Caetano", 2, 6, 4, 13, 13, 1, 0));
        times.add(new TimeFutebol("Santo André", 2, 6, 4, 13, 12, 2, 0));
        times.add(new TimeFutebol("Inter de Limeira", 3, 7, 2, 13, 15, 1, 0));
        times.add(new TimeFutebol("Ferroviária", 3, 7, 2, 13, 15, 1, 1));
        
        Collections.sort(times, Collections.reverseOrder());
        
        System.out.println("Posição | Time | Pontos");
        
        int contador = 1;
        for(TimeFutebol time: times){
            System.out.println(contador+" | "+time.nome+" | "+time.getPontuacao());
            contador++;
        }
    }
}
