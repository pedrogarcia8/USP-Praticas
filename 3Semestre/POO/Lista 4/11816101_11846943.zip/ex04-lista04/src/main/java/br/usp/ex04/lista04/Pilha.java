package br.usp.ex04.lista04;

public class Pilha {
    private int tamanho;
    private int topo;
    private String itens[];
    
    Pilha(int tamanho){
        this.tamanho = tamanho;
        this.topo = -1;
        this.itens = new String[tamanho];
    }
    
    public void push(String palavra) throws PilhaCheia{
        if(topo == (tamanho-1)){
            PilhaCheia PC = new PilhaCheia();
            PC.setMensagemDeErro("Retire um elemento da pilha e tente novamente!");
            throw PC;
        }
        
        this.topo++;
        this.itens[topo] = palavra;
    }
    
    public String pop() throws PilhaVazia{
        if(topo < 0){
            PilhaVazia PV = new PilhaVazia();
            PV.setMensagemDeErro("Adicione um elemento na pilha e tente novamente!");
            throw PV;
        }
        
        String palavra = this.itens[topo];
        this.topo--;
        return palavra;
    }
}
