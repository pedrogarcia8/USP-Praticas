package br.usp.ex04.lista04;

public class PilhaCheia extends PilhaException{
    public PilhaCheia() {
        super("Erro: Pilha Cheia!");
    }
}
