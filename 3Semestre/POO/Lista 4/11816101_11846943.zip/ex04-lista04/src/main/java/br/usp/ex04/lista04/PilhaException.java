package br.usp.ex04.lista04;

public abstract class PilhaException extends Exception{
    private String mensagem;
    
    public PilhaException() {
    }

    public PilhaException(String msg) {
        super(msg);
    }
    
    public void setMensagemDeErro(String msg){
        this.mensagem = msg;
    }
    
    public String getMensagemDeErro(){
        return this.mensagem;
    }
}
