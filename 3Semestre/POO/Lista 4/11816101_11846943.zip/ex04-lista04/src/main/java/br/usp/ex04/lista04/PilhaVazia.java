package br.usp.ex04.lista04;

public class PilhaVazia extends PilhaException{
    public PilhaVazia() {
        super("Erro: Pilha Vazia!");
    }
}
