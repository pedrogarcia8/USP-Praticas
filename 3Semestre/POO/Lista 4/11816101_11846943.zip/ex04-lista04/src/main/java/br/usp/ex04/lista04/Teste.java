package br.usp.ex04.lista04;

import java.util.Scanner;

public class Teste {
    public static void main(String[] Args) throws PilhaException{
        Pilha p = new Pilha(3);
        
        String op = "";
        Scanner myObj = new Scanner(System.in);
        
        while(!op.equals("exit")){
            System.out.println("--------------------------------");
            System.out.println("Digite uma das seguintes opções:");
            System.out.println("- push\n- pop\n- exit\n");
            System.out.println("Opção: ");
            op = myObj.nextLine();
            
            if(op.equals("push")){
                System.out.println("\nDigite o que será colocado na pilha: ");
                String palavra = myObj.nextLine();
                try{
                    p.push(palavra);
                }
                catch(PilhaCheia PC){
                    System.out.println("");
                    System.out.println(PC.getMessage());
                    System.out.println(PC.getMensagemDeErro());
                }
            }
            else if(op.equals("pop")){
                try{
                    System.out.println("\nItem retirado da pilha: " + p.pop());
                }
                catch(PilhaVazia PV){
                    System.out.println("");
                    System.out.println(PV.getMessage());
                    System.out.println(PV.getMensagemDeErro());
                }
            }
            else if(op.equals("exit")){
                break;
            }
            else{
                System.out.println("\nOpção inválida! Tente novamente!");
            }
            System.out.println("");
        }
        
        System.out.println("\nFechando programa!");
    }
}