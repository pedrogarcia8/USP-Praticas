package br.usp.ex05.lista04;

public class DepositarException extends Exception {
    DepositarException(){
        super("O valor do depósito é negativo ou igual a zero");
    }
}
