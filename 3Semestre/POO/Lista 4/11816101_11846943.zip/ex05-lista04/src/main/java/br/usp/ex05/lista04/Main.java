package br.usp.ex05.lista04;

public class Main {
    public static void main(String[] args) throws DepositarException, SacarException{
        ContaCorrente conta = new ContaCorrente(1000, 700); // saldo = 1000, credito = 700
        conta.getExtrato();
        
        conta.setValorLimite(1000); // saldo = 1000, crédito = 1000
        conta.getExtrato();
        
        conta.depositar(100); // saldo = 1100, crédito = 1000
        conta.getExtrato();
        
        conta.sacar(2500); // saldo = 1100, crédito = 1000 -> Exceção
        conta.getExtrato();
        
        conta.depositar(0); // saldo = 1100, crédito = 1000 -> Exceção
        conta.getExtrato();
        
        conta.depositar(-1);// saldo = 1100, crédito = 1000 -> Exceção
        conta.getExtrato();
        
        conta.sacar(300);// saldo = 800, crédito = 1000
        conta.getExtrato();
        
        conta.sacar(1700);// saldo = 0, crédito = 100
        conta.getExtrato();
    }
}
