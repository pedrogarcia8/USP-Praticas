package br.usp.ex2.lista1;

public class SO {
    boolean power;
    rede dRede; //driver de rede
    video dVideo; //driver de vídeo
    impressora dImpressora; //driver de impressora
    
    SO(){
        power = false;
        dRede = new rede();
        dVideo = new video();
        dImpressora = new impressora();
    }

    public void ligaDispositivo(){
        if(power){
            System.out.println("Sistema já está ligado!");
        }
        else{ //liga todos os drivers
            power = true;
            dRede.power = true;
            dVideo.power = true;
            dImpressora.power = true;
            System.out.println("Ligando sistema...");
        }
    }

    public void desligaDispositivo(){
        if(!power){
            System.out.println("Sistema já está desligado!");
        }
        else{ //desliga todos os drivers
            power = false;
            dRede.power = false;
            dVideo.power = false;
            dImpressora.power = false;
            System.out.println("Desligando sistema...");
        }
    }

    public void verificaStatus(){
        System.out.println("Executando testes no sistema...");
        System.out.println("Sistema: " + status(power));
        System.out.println("Status do driver de rede: " + status(dRede.power));
        System.out.println("Status do driver de vídeo: " + status(dVideo.power));
        System.out.println("Status do driver de impressora: " + status(dImpressora.power));
    }

    private String status(boolean disp){
        if(disp){
            return "Online";
        }
        else{
            return "Offline";
        }
    }
    
    public void executaTeste(){
        dRede.executaTeste();
        dVideo.executaTeste();
        dImpressora.executaTeste();
    }
}
