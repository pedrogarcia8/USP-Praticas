package br.usp.ex2.lista1;

public class impressora {
    boolean power;
    
    impressora(){
        power = false;
    }
    
    public void ligaDispositivo(){
        if(power){
            System.out.println("Driver de impressora já está ligado!");
        }
        else{
            power = true;
            System.out.println("Ligando driver de impressora...");
        }
    }

    public void desligaDispositivo(){
        if(!power){
            System.out.println("Driver de impressora já está desligado!");
        }
        else{
            power = false;
            System.out.println("Desligando driver de impressora...");
        }
    }

    public void verificaStatus(){
        if(power){
            System.out.println("Driver de impressora ligado");
        }
        else{
            System.out.println("Driver de impressora desligado");
        }
    }

    public void executaTeste(){
        if(power){
            System.out.println("Imprimindo 1 página em cores...");
            System.out.println("Imprimindo 1 página em preto e branco...");
            System.out.println("Teste concluído!");
        }
        else{
            System.out.println("Impossível realizar teste! Driver de impressora offline");
        }
    }
    
    public void imprimePaginas(int paginas){
        if(power){
            System.out.println("Imprimindo " + paginas + " páginas!");
        }
        else{
            System.out.println("Não foi possível imprimir pois o driver de impressora está desligado!");
        }
    }
}
