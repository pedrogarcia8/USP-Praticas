package br.usp.ex2.lista1;

public class video {
    float brilho; //porcentagem do brilho
    boolean power;
    
    video(){
        brilho = 0.5f;
        power = false;
    }
    
    public void ligaDispositivo(){
        if(power){
            System.out.println("Driver de vídeo já está ligado!");
        }
        else{
            power = true;
            System.out.println("Ligando driver de vídeo...");
        }
    }

    public void desligaDispositivo(){
        if(!power){
            System.out.println("Driver de vídeo já está desligado!");
        }
        else{
            power = false;
            System.out.println("Desligando driver de vídeo...");
        }
    }

    public void verificaStatus(){
        if(power){
            System.out.println("Driver de vídeo ligado");
        }
        else{
            System.out.println("Driver de vídeo desligado");
        }
    }

    public void executaTeste(){
        if(power){
            System.out.println("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
            System.out.println("abcdefghijklmnopqrstuvwxyz");
            System.out.println("Teste concluído!");
        }
        else{
            System.out.println("Impossível realizar teste! Driver de vídeo offline!");
        }
    }
    
    public void alteraBrilhoDeExibição(float b){
        if(power){
            brilho = b;
            System.out.println("O brilho foi alterado para " + brilho*100 + "%!");
        }
        else{
            System.out.println("Não foi possível alterar o brilho pois o driver de vídeo está desligado!");
        }
    }
}
