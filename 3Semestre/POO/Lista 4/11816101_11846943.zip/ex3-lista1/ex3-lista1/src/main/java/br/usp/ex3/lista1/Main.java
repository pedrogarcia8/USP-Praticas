package br.usp.ex3.lista1;

public class Main {
    public static void main(String[] args){
        Polinomio p = new Polinomio(3);
        p.add(3, 2);
        p.add(5, 2);
        p.add(4, 1);
        p.add(-2, 0);
        p.add(5, 4); //Exibirá mensagem de erro, dizendo que grau do termo é maior que o do polinômio
        p.add(4, 4); //Exibirá mensagem de erro, dizendo que grau do termo é maior que o do polinômio
        p.add(-7, 3);
        
        p.mostra(); // Exibirá o polinômio
        float valor = 2;
        float valorCalculado = p.calcula(valor); // Calculará o valor do polinômio para x = 2
        
        System.out.println("P("+valor+") = "+valorCalculado); // Exibirá o valor calculado
    }
}
