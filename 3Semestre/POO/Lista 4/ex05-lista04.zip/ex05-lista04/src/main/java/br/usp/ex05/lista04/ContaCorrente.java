package br.usp.ex05.lista04;

public class ContaCorrente{
    float saldo;
    float creditoLimite;
    
    ContaCorrente(float saldo, float creditoLimite){
        this.saldo = saldo;
        this.creditoLimite = creditoLimite;
    }
    
    public void setValorLimite(float valor){
        this.creditoLimite = valor;
    }
    
    public void depositar(float valor) throws DepositarException{
        try{
            if(valor <= 0){
              throw new DepositarException();  
            }else{
                this.saldo += valor;
            }
        }catch(DepositarException excecao){
            System.out.println(excecao.getMessage());
        }
    }
    
    public void sacar(float valor) throws SacarException{
        try{
            if(valor > (this.saldo + this.creditoLimite)){
              throw new SacarException();  
            }else{
                this.saldo -= valor;
                if(this.saldo < 0){ // Se o valor sacado for maior que o saldo disponível tira do limite de crédito também
                    this.creditoLimite -= this.saldo * (-1);
                    this.saldo = 0;
                }
            }
        }catch(SacarException excecao){
            System.out.println(excecao.getMessage());
        }
    }
    
    public void getExtrato(){
        System.out.println();
        System.out.println("===== Extrato =====");
        System.out.println("Saldo: " +this.saldo);
        System.out.println("Crédito Limite: "+ this.creditoLimite);
        System.out.println();
    }
}
