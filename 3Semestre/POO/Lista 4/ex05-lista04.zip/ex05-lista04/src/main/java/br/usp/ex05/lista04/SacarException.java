package br.usp.ex05.lista04;

public class SacarException extends Exception {
    SacarException(){
        super("Valor do saque acima do permitido!");
    }
}
