package com.mycompany.ex06.lista06;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;


public class Arquivo {
    private String nomeArquivo;
    private String conteudoArquivo;
    
    Arquivo(String nomeArquivo) throws IOException{
        this.setNomeArquivo(nomeArquivo);
        this.conteudoArquivo = leArquivo();
    }
    
    void setNomeArquivo(String nomeArquivo){
        this.nomeArquivo = nomeArquivo;
    }
    
    String leArquivo() throws FileNotFoundException, IOException{
        FileInputStream inputStream = new FileInputStream(this.nomeArquivo);
        try {
            String texto = new String(inputStream.readAllBytes(), StandardCharsets.UTF_8);
            return texto;
        } finally {
            inputStream.close();
        }
    }
    
    String substituirPalavra(){
        String textoSubstituido = this.conteudoArquivo.replaceAll("muito", "pouco");
        return textoSubstituido;
    }
    
    void escreveArquivo() throws IOException{
         FileWriter arquivo = new FileWriter(this.nomeArquivo);
         try{
            PrintWriter gravarArquivo = new PrintWriter(arquivo);
            String novoConteudo = substituirPalavra();
            gravarArquivo.printf(novoConteudo);
         } finally {
            arquivo.close();
         }
    }
}
