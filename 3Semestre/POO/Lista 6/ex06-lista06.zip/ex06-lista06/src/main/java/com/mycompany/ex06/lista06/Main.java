package com.mycompany.ex06.lista06;

import java.io.IOException;

public class Main {
    public static void main(String []args) throws IOException{
        Arquivo arquivo = new Arquivo("C:\\Users\\pjgar\\Desktop\\teste.txt");
        arquivo.escreveArquivo();
        System.out.println("Texto substituído!");
    }
}
