package com.mycompany.ex07.lista06;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Arquivo{
    private String diretorio;
    
    Arquivo(String diretorio){
        this.setDiretorio(diretorio);
    }
    
    void setDiretorio(String diretorio){
        this.diretorio = diretorio;
    }
    
    List<File> manipulaArquivo(){
        File diretorio = new File(this.diretorio);
        File arquivos[] = diretorio.listFiles();
        List<File> arquivosFiltrados = new ArrayList<File>();
        for (int i = 0; i < arquivos.length; i++) {
            if(arquivos[i].getName().toLowerCase().endsWith(".mp3")) {
                arquivosFiltrados.add(arquivos[i]);
            } 
        }
        
        Collections.sort(arquivosFiltrados, new Comparadora());
        
        for(int i = 0; i < arquivosFiltrados.size(); i++){
            String nomeFormatado = String.format("%04d", i+1)+"."+this.formataNome(arquivosFiltrados.get(i).getName());
            String novoNome = arquivosFiltrados.get(i).getAbsolutePath().replace(arquivosFiltrados.get(i).getName(), nomeFormatado);
            arquivosFiltrados.get(i).renameTo(new File(novoNome));
        }
        
        return arquivosFiltrados;
    }
      
    String formataNome(String nome){
        String nomeFormatado = nome.replaceAll("-","");
        nomeFormatado = nomeFormatado.replaceAll("[0-9]","")+"3"; //Recuperando a extensão .mp3
        return nomeFormatado;
    }
    
    
}
