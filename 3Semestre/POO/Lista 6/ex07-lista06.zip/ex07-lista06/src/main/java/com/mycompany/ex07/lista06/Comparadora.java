package com.mycompany.ex07.lista06;

import java.io.File;
import java.util.Comparator;

public class Comparadora implements Comparator<File>  {
    Comparadora(){
        
    }
    
    public int compare(File arquivo1, File arquivo2){
        return (int) arquivo1.length() - (int) arquivo2.length();
    }
}
