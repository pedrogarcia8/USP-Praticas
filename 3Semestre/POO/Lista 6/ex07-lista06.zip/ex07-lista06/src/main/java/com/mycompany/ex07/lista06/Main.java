package com.mycompany.ex07.lista06;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String []args){
        Arquivo diretorio = new Arquivo("C:\\Users\\pjgar\\Desktop\\teste");
        
        List<File> arquivosFiltrados = diretorio.manipulaArquivo();
        System.out.println("Arquivos manipulados");
    }
}
