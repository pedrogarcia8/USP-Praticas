package com.mycompany.ex03a.lista07;

public class Main {
    public static void main(String[] args){
        Operations operation = new Operations();
        BankThread bank1 = new BankThread(operation);
        UserThread user1 = new UserThread(operation);
        BankThread bank2 = new BankThread(operation);
        UserThread user2 = new UserThread(operation);
        
        user1.start();
        bank1.start();
        user2.start();
        bank2.start();
    }
}
