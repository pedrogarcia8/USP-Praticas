package com.mycompany.ex03a.lista07;


public class Operations {
    int saldo;
    
    public void deposita(int iValor){
        System.out.println("Saldo Atual: " + this.saldo);
        int novoSaldo = this.saldo + iValor;
        System.out.println("Novo saldo: " + novoSaldo);
        this.saldo = novoSaldo;
    }
    
    public int saca(int iValor){
        System.out.println("Saldo Atual: " + this.saldo);
        int novoSaldo = this.saldo - iValor;
        
        if(novoSaldo < 0){
            novoSaldo = 0;
        }
        
        System.out.println("Novo saldo: " + novoSaldo);
        this.saldo = novoSaldo;
        return novoSaldo;
    }
}
