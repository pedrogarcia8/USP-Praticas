package com.mycompany.ex03a.lista07;


public class UserThread extends Thread{
    private Operations operation;
    private int valorSacado;
    
    public UserThread(Operations operation){
        this.operation = operation;
    }
    
    public void run(){
        for(int i = 0; i < 5000; i++)
            this.valorSacado = operation.saca(800);
    }
}
