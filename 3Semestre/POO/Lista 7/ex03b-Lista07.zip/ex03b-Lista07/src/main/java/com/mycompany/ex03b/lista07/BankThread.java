package com.mycompany.ex03b.lista07;

public class BankThread extends Thread{
    private Operations operation;
    
    public BankThread(Operations operation){
        this.operation = operation;
    }
    
    public void run() {
        for (int i = 0; i < 5000; i++)
            operation.deposita(1000);
    }
}
