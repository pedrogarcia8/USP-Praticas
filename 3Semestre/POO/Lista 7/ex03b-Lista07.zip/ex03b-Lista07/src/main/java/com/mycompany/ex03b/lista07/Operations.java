package com.mycompany.ex03b.lista07;


public class Operations {
    int saldo;
    boolean disponibilidade = true;
    
    public synchronized void deposita(int iValor){
        if (disponibilidade == true) {
            try {
                wait(); /*aguarda até termina o método saca*/
            } catch (InterruptedException e) { }
        }
        this.disponibilidade = false;
        
        System.out.println("Saldo Atual: " + this.saldo);
        int novoSaldo = this.saldo + iValor;
        System.out.println("Novo saldo: " + novoSaldo);
        this.saldo = novoSaldo;
        notify();
    }
    
    public synchronized int saca(int iValor){
        if (disponibilidade == false) {
            try {
                wait(); /*aguarda até termina o método deposita*/
            } catch (InterruptedException e) { }
        }
        this.disponibilidade = true;
        
        System.out.println("Saldo Atual: " + this.saldo);
        int novoSaldo = this.saldo - iValor;
        
        if(novoSaldo < 0){
            novoSaldo = 0;
        }
        
        System.out.println("Novo saldo: " + novoSaldo);
        this.saldo = novoSaldo;
        
        notify();
        
        return novoSaldo;
    }
}
