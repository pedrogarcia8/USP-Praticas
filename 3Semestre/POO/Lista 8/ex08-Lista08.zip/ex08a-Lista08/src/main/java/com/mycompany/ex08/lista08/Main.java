package com.mycompany.ex08.lista08;

public class Main {
   public static void main(String[] args){    
       
       //Sem proxy
       Sistema sistema = new Sistema();
       sistema.setChave("aesd789dkoj");
       sistema.liberaSistema("aesd789dkoj");
       
       //Com proxy
       SistemaProxy sistemaProxy = new SistemaProxy();
       sistemaProxy.setChave("aesd789dkoj");
       sistemaProxy.liberaSistema("aesd789dkoj");
       
   }
}
