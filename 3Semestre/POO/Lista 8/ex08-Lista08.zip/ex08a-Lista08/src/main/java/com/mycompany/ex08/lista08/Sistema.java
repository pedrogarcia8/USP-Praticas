package com.mycompany.ex08.lista08;

public class Sistema {
    private String chave;
    Sistema(){
        
    }
    
    void setChave(String chave){
        if(chave.contains("789"))
            System.out.println("FALHA DE SEGURANCA - SISTEMA ESTA VULNERAVEL!.");
        else{
            this.chave = chave;
        }
    }
    
    void liberaSistema(String chave){
        if(chave.contains("789"))
            System.out.println("FALHA DE SEGURANCA - SISTEMA ESTA VULNERAVEL!.");
        else if(this.chave.equals(chave))
            System.out.println("SISTEMA LIBERADO!");
        else
           System.out.println("SISTEMA BLOQUEADO!"); 
    }
}
