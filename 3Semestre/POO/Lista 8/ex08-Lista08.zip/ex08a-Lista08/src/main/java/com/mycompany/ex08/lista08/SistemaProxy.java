package com.mycompany.ex08.lista08;

public class SistemaProxy {
    Sistema sistema;
    public SistemaProxy(){
        sistema = new Sistema();
    }
    
    public void setChave(String chave){
        if(chave.contains("789"))
            throw new Error("ERRO: tentativa de execucao de codigo malicioso");
        else{
            sistema.setChave(chave);
        }
    }
    
    public void liberaSistema(String chave){
        if(chave.contains("789"))
            throw new Error("ERRO: tentativa de execucao de codigo malicioso");
        else 
            sistema.liberaSistema(chave);
    }
}
