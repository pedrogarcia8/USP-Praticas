package com.mycompany.ex08b.lista08;

public abstract class DecoratorFilteredSistema implements IFilteredSistema {
    private IFilteredSistema filteredSistema;

    public DecoratorFilteredSistema(IFilteredSistema filteredSistema){
        this.filteredSistema = filteredSistema;
    }
    
    @Override
    public String protegeSistema(String chave) {
        return filteredSistema.protegeSistema(chave);
    }
    
    
}
