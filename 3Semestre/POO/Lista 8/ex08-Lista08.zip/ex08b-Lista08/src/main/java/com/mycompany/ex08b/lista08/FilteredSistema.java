package com.mycompany.ex08b.lista08;

public class FilteredSistema implements IFilteredSistema{
    FilteredSistema(){
        
    }
    
    public String protegeSistema(String chave){
        if(chave.contains("789")){
            String[] array = chave.split("789");
            String novaChave = "";

            for(int i = 0; i < array.length; i++){
                novaChave = novaChave.concat(array[i]);
                novaChave = novaChave.concat("987");
            }
            
            return novaChave.substring(0, novaChave.length()-3); 
        }else
            return chave; 
    }
}
