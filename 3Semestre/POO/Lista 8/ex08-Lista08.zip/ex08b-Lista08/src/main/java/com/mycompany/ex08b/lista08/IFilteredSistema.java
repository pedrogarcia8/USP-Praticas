package com.mycompany.ex08b.lista08;

public interface IFilteredSistema {
    String protegeSistema(String chave);
}
