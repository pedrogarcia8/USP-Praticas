package com.mycompany.ex08b.lista08;

public class Main {
    public static void main(String[] args){    
       Sistema sistema = new Sistema();
       sistema.setChave("aesd789dkoj");
       sistema.liberaSistema("aesd789dkoj"); 
   }
}
