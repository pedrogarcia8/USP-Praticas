package com.mycompany.ex10.lista08;

import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        Palavra palavra = new Palavra();
    
        ObserverMaiuscula omPalavra = new ObserverMaiuscula();
        ObserverAno oaPalavra = new ObserverAno();
        ObserverTamanho otPalavra = new ObserverTamanho();

        palavra.addObserver(omPalavra);
        palavra.addObserver(oaPalavra);
        palavra.addObserver(otPalavra);
        
        Scanner scan = new Scanner(System.in);
        while(true){
            System.out.println("Entre com uma nova palavra: ");
            palavra.setPalavra(scan.nextLine());
            
            palavra.notifyObservers(palavra);
        }
    }
}
