package com.mycompany.ex10.lista08;

import java.time.LocalDate;
import java.util.Observable;
import java.util.Observer;

public class ObserverAno implements Observer{
    private String palavra;
    
    @Override
    public void update(Observable o, Object arg) {
        Palavra temp = (Palavra)o;
        palavra = temp.getPalavra();
        palavra = palavra.concat(Integer.toString(LocalDate.now().getYear()));
        System.out.println("Observador Ano: "+palavra);
    }
}
