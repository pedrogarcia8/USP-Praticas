package com.mycompany.ex10.lista08;

import java.util.Observable;
import java.util.Observer;


public class ObserverMaiuscula implements Observer {
    private String palavra;
    
    @Override
    public void update(Observable o, Object arg) {
        Palavra temp = (Palavra)o;
        palavra = temp.getPalavra();
        System.out.println("Observador Maiuscula: "+palavra.toUpperCase());
    }
    
}
