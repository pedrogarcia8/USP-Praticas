package com.mycompany.ex10.lista08;

import java.time.LocalDate;
import java.util.Observable;
import java.util.Observer;


public class ObserverTamanho implements Observer{
    private String palavra;
    
    @Override
    public void update(Observable o, Object arg) {
        Palavra temp = (Palavra)o;
        palavra = temp.getPalavra();
        palavra = palavra.concat(Integer.toString(palavra.length()));
        System.out.println("Observador Tamanho: "+palavra);
    }
    
}
