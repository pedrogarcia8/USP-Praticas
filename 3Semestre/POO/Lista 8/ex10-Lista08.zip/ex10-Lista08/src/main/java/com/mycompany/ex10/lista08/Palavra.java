package com.mycompany.ex10.lista08;

import java.util.Observable;

public class Palavra extends Observable{
    private String palavra;
    
    Palavra(){
        
    }
    
    void setPalavra(String palavra){
        this.palavra = palavra;
        this.setChanged();
    }
    
    String getPalavra(){
        return palavra;
    }

}
