package com.mycompany.ex02.lista09;

import java.util.Random;

public class Main {
    public static void main(String[] args){
        Tipo[] t = new Tipo[10];
        Random random = new Random();
        
        for(int i = 0; i < 10; i++){
            t[i] = new Tipo((Integer) random.nextInt(100));
            System.out.println(t[i].toString());
        }
        
        System.out.println("\nOrdenado:\n");
        
        insertionSort(t);
        
        for(int i = 0; i < t.length; i++){
            System.out.println(t[i].toString());
        }
    }
    
    static void insertionSort(Tipo[] A){
        Comparadora comp = new Comparadora();
        
        for(int i = 1; i < A.length; i++){
            Tipo temp = A[i];
            int j = i - 1;
            while(j > -1 && comp.compare(A[j].getValue(), temp.getValue()) == 1){ 
                A[j+1] = A[j];
                j--;
            }
            A[j+1] = temp;
        }
    }
}
