package com.mycompany.ex02.lista09;

import java.util.Comparator;

public class Tipo<T>{
   private T value;

   public Tipo(T value) {
       this.setValue(value);
   }

   public void setValue(T newValue) {
       this.value = newValue;
   } 
   
   public T getValue(){
       return this.value;
   }
   
   public String toString(){
       return ("Value: "+value.toString());
   }
}
