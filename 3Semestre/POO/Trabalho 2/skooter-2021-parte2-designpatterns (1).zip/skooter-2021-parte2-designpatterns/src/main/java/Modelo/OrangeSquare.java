package Modelo;

public class OrangeSquare extends Elemento{
    
    public OrangeSquare(String sNomeImagePNG) {
        super(sNomeImagePNG);
        this.bTransponivel = false;
    }
    
    public void autoDesenho(){ 
        super.autoDesenho();
    }
}
