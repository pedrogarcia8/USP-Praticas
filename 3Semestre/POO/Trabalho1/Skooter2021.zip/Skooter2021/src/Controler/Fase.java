package Controler;

import Modelo.*;
import Auxiliar.*;
import java.util.ArrayList;

public class Fase {
    private Hero hHero;
    private ArrayList<Elemento> eElementos;
    private int numeroFase;
    
    public Fase(int numeroFase){
        this.numeroFase = numeroFase;
        eElementos = new ArrayList<Elemento>(121);
        
        hHero = new Hero("hero.png");  
        hHero.setPosicao(4, 4);
        this.addElemento(hHero);
        
        switch(numeroFase) {
            case 1:
                this.cenarioPrimeiraFase();
              break;
            case 2:
              // code block
              break;
            case 3:
              // code block
              break;
            case 4:
              // code block
              break;
            case 5:
              // code block
              break;
          }
    }
    
    public ArrayList<Elemento> getFase(){
        return eElementos;
    }
    
    public Hero getHero(){
        return hHero;
    }
    
    private void cenarioPrimeiraFase(){        
        //Desenhando quadrados verdes
        GreenSquare greenSquare;
        for(int i = 3; i <= 9; i+=6){
            greenSquare = new GreenSquare("greenSquare.png");
            greenSquare.setPosicao(i, 0);
            this.addElemento(greenSquare);
        }
        
        for(int i = 0; i <= 5; i+=2){
            greenSquare = new GreenSquare("greenSquare.png");
            greenSquare.setPosicao(i, 1);
            this.addElemento(greenSquare);
        }
        
        for(int i = 1; i <= 11; i+=4){
            greenSquare = new GreenSquare("greenSquare.png");
            greenSquare.setPosicao(i, 2);
            this.addElemento(greenSquare);
        }
        
        greenSquare = new GreenSquare("greenSquare.png");
        greenSquare.setPosicao(8, 3);
        this.addElemento(greenSquare);
            
        for(int i = 0; i <= 6; i+=2){
            if(i == 4)
                i += 2;
            
            greenSquare = new GreenSquare("greenSquare.png");
            greenSquare.setPosicao(i, 5);
            this.addElemento(greenSquare);
        }
        
        for(int i = 5; i <= 11; i+=4){
            greenSquare = new GreenSquare("greenSquare.png");
            greenSquare.setPosicao(i, 6);
            this.addElemento(greenSquare);
        }
        
        for(int i = 6; i <= 11; i+=4){
            greenSquare = new GreenSquare("greenSquare.png");
            greenSquare.setPosicao(i, 7);
            this.addElemento(greenSquare);
        }
        
        for(int i = 1; i <= 11; i+=2){
            if(i == 5)
                i += 2;
            
            greenSquare = new GreenSquare("greenSquare.png");
            greenSquare.setPosicao(i, 8);
            this.addElemento(greenSquare);
        }
        
        for(int i = 4; i <= 11; i+=4){
            greenSquare = new GreenSquare("greenSquare.png");
            greenSquare.setPosicao(i, 9);
            this.addElemento(greenSquare);
        }
        
        for(int i = 1; i <= 11; i+=6){
            greenSquare = new GreenSquare("greenSquare.png");
            greenSquare.setPosicao(i, 10);
            this.addElemento(greenSquare);
        }
        
        OrangeSquare orangeSquare; //Desenhando quadrados laranjas
        for(int i = 1; i <= 9; i+=2){
            for(int j = 1; j <= 9; j+=2){
                orangeSquare = new OrangeSquare("orangeSquare.png");
                orangeSquare.setPosicao(i, j);
                this.addElemento(orangeSquare);
            }
        }
        
        //Desenhando o cacho de uva
        BunchOfGrapes bunchOfGrapes = new BunchOfGrapes("bunchOfGrapes.png");
        bunchOfGrapes.setPosicao(0, 0);
        this.addElemento(bunchOfGrapes); 
        
        //Desenhando o mamão
        Papaya papaya = new Papaya("papaya.png");
        papaya.setPosicao(0, 10);
        this.addElemento(papaya);
        
        //Desenhando o morango
        Strawberry strawberry = new Strawberry("strawberry.png");
        strawberry.setPosicao(10, 0);
        this.addElemento(strawberry);
        
        //Desenhando a cereja
        Cherry cherry = new Cherry("cherry.png");
        cherry.setPosicao(10, 10);
        this.addElemento(cherry);
    }
    
    private void addElemento(Elemento umElemento) {
        eElementos.add(umElemento);
    }
}
